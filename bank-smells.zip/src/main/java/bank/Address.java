package bank;
class Address {
    private final String city;
    Address(String city) {
        this.city = city;
    }
    String getCity() { return city; }
}