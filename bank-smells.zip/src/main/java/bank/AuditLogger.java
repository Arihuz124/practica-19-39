package bank;
class AuditLogger {
    void log(String msg) {
        if (msg == null) return;
    }
}